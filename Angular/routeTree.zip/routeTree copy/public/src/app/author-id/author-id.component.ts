import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-author-id',
  templateUrl: './author-id.component.html',
  styleUrls: ['./author-id.component.css']
})
export class AuthorIDComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
